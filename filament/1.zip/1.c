#include<stdio.h>

 main()
{
    char string[40];
    int length=0, a=1,i;

    printf("Enter string:\n");
    gets(string);

    for(i=0;string[i]!='\0';i++)
    {
        length++;
    }

    for(i=0;i< length/2;i++)
    {
        if( string[i] != string[length-1-i] )
        {
            a=0;
            break;
        }
    }

    if(a==1)
    {
        printf("PALINDROME");
    }
    else
    {
        printf("NOT PALINDROME");
    }
}

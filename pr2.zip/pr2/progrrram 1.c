#include<stdio.h>

main(){
	int a;
	
	printf("Enter the number: ");
	scanf("%d",&a);
	
	(a/2)?printf("This number is even"):printf("This number is odd");
}

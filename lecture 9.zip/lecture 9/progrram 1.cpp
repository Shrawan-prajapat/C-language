#include<stdio.h>

main(){
	int i=1,j=10;
	
	do{
		printf("%d",i);
	}while(i<=j);
}

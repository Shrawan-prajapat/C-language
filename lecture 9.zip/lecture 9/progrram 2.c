#include<stdio.h>

main(){
	int i,n;
	i=10;
	n=1;
	
	
	do{
		printf("%d\n",i);
		i--;
	}while(i>=n);
}

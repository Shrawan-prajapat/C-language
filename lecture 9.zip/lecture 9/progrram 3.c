#include<stdio.h>

main(){
	
	int i=1,n;
	

	printf("Enter value of i: ");
	scanf("%d",&n);

	while(i<=n){
		if(i%2!=0){
			
		}
		else{
			printf("%d\t",i);
		}
		
		i++;
	}
}

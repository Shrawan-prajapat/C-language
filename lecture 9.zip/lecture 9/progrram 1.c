#include<stdio.h>

main(){
	
	int i=1,n=10;

	do{
		printf("%d\n",i);
		i++;
	}while(i<=n);
}

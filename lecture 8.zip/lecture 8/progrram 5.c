#include<stdio.h>

main(){
	
	int i = 1,n;
	
	
	
	printf("Enter value of ending number: ");
	scanf("%d",&n);
	
	while(i<=n){
		printf("%d\n",i);
		
		i++;
	}
}
